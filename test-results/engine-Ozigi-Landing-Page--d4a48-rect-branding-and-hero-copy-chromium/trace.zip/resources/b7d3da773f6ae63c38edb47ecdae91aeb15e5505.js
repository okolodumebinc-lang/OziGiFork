(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_8df590c1._.js",
  "static/chunks/843f0_next_dist_compiled_react-dom_fca56727._.js",
  "static/chunks/843f0_next_dist_compiled_next-devtools_index_133accd9.js",
  "static/chunks/843f0_next_dist_compiled_5463e7e8._.js",
  "static/chunks/843f0_next_dist_client_73cb0208._.js",
  "static/chunks/843f0_next_dist_4eae3cca._.js",
  "static/chunks/69652_@swc_helpers_cjs_77b72907._.js"
],
    source: "entry"
});
