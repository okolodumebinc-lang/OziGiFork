(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_2b63251a._.js",
  "static/chunks/80809_@supabase_auth-js_dist_module_29396c8e._.js",
  "static/chunks/c2567_motion-dom_dist_es_65112299._.js",
  "static/chunks/bb759_framer-motion_dist_es_b9441129._.js",
  "static/chunks/node_modules__pnpm_536d1538._.js"
],
    source: "dynamic"
});
